var config = {
    map: {
        '*': {
            'md_deeplink_post_redirect': 'Magedelight_SubscribenowPro/js/md_deeplink_post_redirect',
            'md_moment_js': 'Magedelight_SubscribenowPro/js/moment.min',
            'md_daterangepicker_js': 'Magedelight_SubscribenowPro/js/daterangepicker.min',
            'md_subscribenowpro_report': 'Magedelight_SubscribenowPro/js/md_subscribenowpro_report'
        }
    }
};